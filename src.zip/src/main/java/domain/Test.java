package domain;

/**
 * Created by 王阳阳 on 2017/7/10.
 */
//实验
public class Test {
    private Integer id;
    private String name;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
